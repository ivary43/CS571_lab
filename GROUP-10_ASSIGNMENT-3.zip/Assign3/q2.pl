notgate(false).
notgate(true):-fail.

notgate(false,true).
notgate(true,false).

notgate(X) :- X, !, fail.
notgate(X).


orgate(true,true).
orgate(true,false).
orgate(false,true).
orgate(false,false):-fail.

orgate(true,true,true).
orgate(true,false,true).
orgate(false,true,true).
orgate(false,false,false).

orgate(X, Y) :- X, !, true.
orgate(X, Y) :- Y, !, true.


andgate(true,true).
andgate(true,false):-fail.
andgate(false,true):-fail.
andgate(false,false):-fail.

andgate(true,true,true).
andgate(true,false,false).
andgate(false,true,false).
andgate(false,false,false).

andgate(X, Y) :- X, !, Y.

xorgate(A,B):-notgate(B,X), notgate(A,Y), andgate(A,X,Z), andgate(Y,B,W), orgate(Z,W).

% xorgate(A, B) :- orgate(andgate(A, notgate(B)), andgate(notgate(A), B)).

in(N, X) :- andgate(connected(M, in(N, X)), input(M)), signal(M, Sigm).
in(N, X) :- connected(M, in(N, X)), out(M).

out(X) :- type(X, notgate), connected(A, in(1, X)), !, notgate(in(1, X)).
out(X) :- type(X, notgate), write('Wire open at NOT gate\n'), !.
out(X) :- type(X, orgate), connected(A, in(1, X)), connected(B, in(2, X)), !, orgate(in(1, X), in(2, X)).
out(X) :- type(X, orgate), write('Wire open at OR gate\n'), !.
out(X) :- type(X, andgate), connected(A, in(1, X)), connected(B, in(2, X)), !, andgate(in(1, X), in(2, X)).
out(X) :- type(X, andgate), write('Wire open at AND gate\n'), !.
out(X) :- type(X, xorgate), connected(A, in(1, X)), connected(B, in(2, X)), !, xorgate(in(1, X), in(2, X)).
out(X) :- type(X, xorgate), write('Wire open at XOR gate\n'), !.


signal(1, true).
signal(2, true).
signal(3, true).

input(1).
input(2).
input(3).

connected(1, in(1, g1)).
connected(1, in(1, g4)).
connected(2, in(2, g1)).
connected(2, in(2, g4)).
connected(3, in(2, g2)).
connected(3, in(2, g3)).
connected(g1, in(1, g2)).
connected(g1, in(1, g3)).
connected(g3, in(1, g5)).
connected(g4, in(2, g5)).

type(g1, xorgate).
type(g2, xorgate).
type(g3, andgate).
type(g4, andgate).
type(g5, orgate).

output:- out(g2).